package com.snhu.sslserver;

import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}
@RestController
class ServerController{   
    //hashing function
	public static String checkSumVerify(String n) throws NoSuchAlgorithmException {
		
		//calling sha256 utilizing message digest
		MessageDigest md = MessageDigest.getInstance("SHA-256");
		byte[] digest = md.digest(n.getBytes(StandardCharsets.UTF_8));
		
		//Convert byte array into signum representation
		BigInteger number = new BigInteger(1, digest);
		
		// Convert message digest into hex value
		StringBuilder hexString = new StringBuilder(number.toString(16));
		
		//pad string with leading zeros
		while(hexString.length() < 64) {
			hexString.insert(0,  '0');
		}
		return hexString.toString();
	}
	
	
	@RequestMapping("/hash")
    public String myHash() throws NoSuchAlgorithmException {
    	String data = "Hello World, From Jonathan Vest!";
    	
    	String checkSum = checkSumVerify(data);
    	
        return "<p>data: "+data + " |  SHA-256 |" + " CheckSum Value:  " + checkSum;
    }
	
	@RequestMapping("/")
    public String myGet() {
    	String data = "Not implemented";
    	
        return "<p>data:"+data;
    }
}